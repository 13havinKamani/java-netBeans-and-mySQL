package javamysql.ui;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class LockscreenGUI extends javax.swing.JFrame
{ 
    String mastercode =".*19.*";
    int code1;
    int code2;
    int code3;
    int code4;
    
    int buttonclicked ;
    
    int count;
    ImageIcon filled = new ImageIcon (getClass().getResource("/images/circle_filled.png"));
    ImageIcon unfilled = new ImageIcon (getClass().getResource("/images/circle_unfilled.png"));
    
    
    public LockscreenGUI()
    {
        initComponents();
    }
    
    public void circlecontrol()
    {
       count++;
       switch (count)
       { case 1:
           Code1.setIcon(filled);
           code1 = buttonclicked;
           break;
           
        case 2:
           Code2.setIcon(filled);
           code2 = buttonclicked;
           break;
               
        case 3:
           Code3.setIcon(filled);
           code3= buttonclicked;
           break;
                   
         case 4:
           Code4.setIcon(filled);
           code4 = buttonclicked;
           
           String mastertest = code1 + "" + code2 + "" + code3  + "" + code4 ;
           
           if (mastertest.matches(mastercode))
                   {
                        home h =new home();
                 h.setVisible(true);
                   }
           else {
               JOptionPane.showMessageDialog(null, "your password is incorrect ");
               
           }
           
           Code1.setIcon(unfilled); 
           Code2.setIcon(unfilled);
           Code3.setIcon(unfilled);
           Code4.setIcon(unfilled);
           
           count=0;
           
           break;
             
           
           
           
       }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        passcode = new javax.swing.JLabel();
        Button0 = new javax.swing.JLabel();
        Button9 = new javax.swing.JLabel();
        Button8 = new javax.swing.JLabel();
        Button7 = new javax.swing.JLabel();
        Button6 = new javax.swing.JLabel();
        Button5 = new javax.swing.JLabel();
        Button4 = new javax.swing.JLabel();
        Button3 = new javax.swing.JLabel();
        Button2 = new javax.swing.JLabel();
        Button1 = new javax.swing.JLabel();
        Code4 = new javax.swing.JLabel();
        Code3 = new javax.swing.JLabel();
        Code2 = new javax.swing.JLabel();
        Code1 = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Lockscreen");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        passcode.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        passcode.setForeground(new java.awt.Color(255, 255, 255));
        passcode.setText("Enter Passcode");
        getContentPane().add(passcode, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 40, 140, 40));

        Button0.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button0.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button0MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button0MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button0MouseReleased(evt);
            }
        });
        Button0.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button0MouseMoved(evt);
            }
        });
        getContentPane().add(Button0, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 360, 60, 60));

        Button9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button9MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button9MouseReleased(evt);
            }
        });
        Button9.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button9MouseMoved(evt);
            }
        });
        getContentPane().add(Button9, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 60, 70));

        Button8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button8MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button8MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button8MouseReleased(evt);
            }
        });
        Button8.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button8MouseMoved(evt);
            }
        });
        getContentPane().add(Button8, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 60, 60));

        Button7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button7MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button7MouseReleased(evt);
            }
        });
        Button7.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button7MouseMoved(evt);
            }
        });
        getContentPane().add(Button7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 290, 60, 60));

        Button6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button6MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button6MouseReleased(evt);
            }
        });
        Button6.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button6MouseMoved(evt);
            }
        });
        getContentPane().add(Button6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 220, 60, 50));

        Button5.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button5MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button5MouseReleased(evt);
            }
        });
        Button5.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button5MouseMoved(evt);
            }
        });
        getContentPane().add(Button5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 220, 60, 50));

        Button4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button4MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button4MouseReleased(evt);
            }
        });
        Button4.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button4MouseMoved(evt);
            }
        });
        getContentPane().add(Button4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 60, 60));

        Button3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button3MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button3MouseReleased(evt);
            }
        });
        Button3.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button3MouseMoved(evt);
            }
        });
        getContentPane().add(Button3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 60, 60));

        Button2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button2MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button2MouseReleased(evt);
            }
        });
        Button2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button2MouseMoved(evt);
            }
        });
        getContentPane().add(Button2, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 140, 60, 60));

        Button1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Button1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                Button1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                Button1MouseExited(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                Button1MouseReleased(evt);
            }
        });
        Button1.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                Button1MouseMoved(evt);
            }
        });
        getContentPane().add(Button1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 60, 60));

        Code4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/circle_unfilled.png"))); // NOI18N
        getContentPane().add(Code4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 30, 30));

        Code3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/circle_unfilled.png"))); // NOI18N
        getContentPane().add(Code3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 80, 30, 30));

        Code2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/circle_unfilled.png"))); // NOI18N
        getContentPane().add(Code2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 20, 30));

        Code1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/circle_unfilled.png"))); // NOI18N
        getContentPane().add(Code1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, 20, 30));

        Background.setBackground(new java.awt.Color(103, 65, 114));
        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/background.png"))); // NOI18N
        getContentPane().add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 295, 460));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void Button1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button1MouseReleased
       
        buttonclicked=1;
        circlecontrol();
    }//GEN-LAST:event_Button1MouseReleased

    private void Button2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button2MouseReleased
       buttonclicked=2;
        circlecontrol();
        

    }//GEN-LAST:event_Button2MouseReleased

    private void Button3MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button3MouseReleased
        buttonclicked=3;
        circlecontrol();
    }//GEN-LAST:event_Button3MouseReleased

    private void Button4MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button4MouseReleased
        buttonclicked=4;
        circlecontrol();
    }//GEN-LAST:event_Button4MouseReleased

    private void Button5MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button5MouseReleased
       buttonclicked=5;
        circlecontrol();
    }//GEN-LAST:event_Button5MouseReleased

    private void Button6MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button6MouseReleased
        buttonclicked=6;
        circlecontrol();
    }//GEN-LAST:event_Button6MouseReleased

    private void Button7MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button7MouseReleased
        buttonclicked=7;
        circlecontrol();
    }//GEN-LAST:event_Button7MouseReleased

    private void Button8MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button8MouseReleased
       buttonclicked=8;
        circlecontrol();
    }//GEN-LAST:event_Button8MouseReleased

    private void Button9MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button9MouseReleased
      buttonclicked=9;
        circlecontrol();
    }//GEN-LAST:event_Button9MouseReleased

    private void Button0MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button0MouseReleased
       buttonclicked=0;
        circlecontrol();
    }//GEN-LAST:event_Button0MouseReleased

    private void Button1MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button1MouseMoved
   
    }//GEN-LAST:event_Button1MouseMoved

    private void Button2MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button2MouseMoved
        
    }//GEN-LAST:event_Button2MouseMoved

    private void Button3MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button3MouseMoved
       
    }//GEN-LAST:event_Button3MouseMoved

    private void Button4MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button4MouseMoved
       
    }//GEN-LAST:event_Button4MouseMoved

    private void Button5MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button5MouseMoved
        
    }//GEN-LAST:event_Button5MouseMoved

    private void Button6MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button6MouseMoved
     
    }//GEN-LAST:event_Button6MouseMoved

    private void Button7MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button7MouseMoved
        
    }//GEN-LAST:event_Button7MouseMoved

    private void Button8MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button8MouseMoved
      
    }//GEN-LAST:event_Button8MouseMoved

    private void Button9MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button9MouseMoved
        
    }//GEN-LAST:event_Button9MouseMoved

    private void Button0MouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button0MouseMoved
      
    }//GEN-LAST:event_Button0MouseMoved

    private void Button1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button1MouseEntered
         ImageIcon x = new ImageIcon (getClass().getResource("/Images/1.png"));
       Background.setIcon(x);
    }//GEN-LAST:event_Button1MouseEntered

    private void Button1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button1MouseExited
         ImageIcon u = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(u);
    }//GEN-LAST:event_Button1MouseExited

    private void Button2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button2MouseEntered
         ImageIcon q = new ImageIcon (getClass().getResource("/Images/2.png"));
       Background.setIcon(q);
    }//GEN-LAST:event_Button2MouseEntered

    private void Button2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button2MouseExited
         ImageIcon w = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(w);
    }//GEN-LAST:event_Button2MouseExited

    private void Button3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button3MouseEntered
         ImageIcon e = new ImageIcon (getClass().getResource("/Images/3.png"));
       Background.setIcon(e);
    }//GEN-LAST:event_Button3MouseEntered

    private void Button3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button3MouseExited
ImageIcon r = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(r);        
    }//GEN-LAST:event_Button3MouseExited

    private void Button4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button4MouseEntered
ImageIcon w = new ImageIcon (getClass().getResource("/Images/4.png"));
       Background.setIcon(w);        // TODO add your handling code here:
    }//GEN-LAST:event_Button4MouseEntered

    private void Button4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button4MouseExited
       ImageIcon w = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(w);
    }//GEN-LAST:event_Button4MouseExited

    private void Button5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button5MouseEntered
       ImageIcon t = new ImageIcon (getClass().getResource("/Images/5.png"));
       Background.setIcon(t);
    }//GEN-LAST:event_Button5MouseEntered

    private void Button5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button5MouseExited
       ImageIcon p = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(p);
    }//GEN-LAST:event_Button5MouseExited

    private void Button6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button6MouseEntered
       ImageIcon j = new ImageIcon (getClass().getResource("/Images/6.png"));
       Background.setIcon(j);
    }//GEN-LAST:event_Button6MouseEntered

    private void Button6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button6MouseExited
      ImageIcon l = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(l);
    }//GEN-LAST:event_Button6MouseExited

    private void Button7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button7MouseEntered
        ImageIcon w = new ImageIcon (getClass().getResource("/Images/7.png"));
       Background.setIcon(w);
    }//GEN-LAST:event_Button7MouseEntered

    private void Button7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button7MouseExited
ImageIcon m = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(m);        
    }//GEN-LAST:event_Button7MouseExited

    private void Button8MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button8MouseEntered
        ImageIcon b = new ImageIcon (getClass().getResource("/Images/8.png"));
       Background.setIcon(b);
    }//GEN-LAST:event_Button8MouseEntered

    private void Button8MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button8MouseExited
        ImageIcon z = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(z);
    }//GEN-LAST:event_Button8MouseExited

    private void Button9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button9MouseEntered
       ImageIcon f = new ImageIcon (getClass().getResource("/Images/9.png"));
       Background.setIcon(f);
    }//GEN-LAST:event_Button9MouseEntered

    private void Button9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button9MouseExited
        ImageIcon h = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(h);
    }//GEN-LAST:event_Button9MouseExited

    private void Button0MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button0MouseEntered
        ImageIcon n = new ImageIcon (getClass().getResource("/Images/0.png"));
       Background.setIcon(n);
    }//GEN-LAST:event_Button0MouseEntered

    private void Button0MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Button0MouseExited
        ImageIcon g = new ImageIcon (getClass().getResource("/Images/background.png"));
       Background.setIcon(g);
    }//GEN-LAST:event_Button0MouseExited

    public static void main(String args[])
    {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try
        {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels())
            {
                if ("Windows".equals(info.getName()))
                {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        }
        catch (ClassNotFoundException ex)
        {
            java.util.logging.Logger.getLogger(LockscreenGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (InstantiationException ex)
        {
            java.util.logging.Logger.getLogger(LockscreenGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (IllegalAccessException ex)
        {
            java.util.logging.Logger.getLogger(LockscreenGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        catch (javax.swing.UnsupportedLookAndFeelException ex)
        {
            java.util.logging.Logger.getLogger(LockscreenGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                try
                {
                 Thread.sleep(1000);   
                    
                    
                }
                catch(Exception e)
                {
                    
                }
                
                
                
                
                new LockscreenGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Background;
    private javax.swing.JLabel Button0;
    private javax.swing.JLabel Button1;
    private javax.swing.JLabel Button2;
    private javax.swing.JLabel Button3;
    private javax.swing.JLabel Button4;
    private javax.swing.JLabel Button5;
    private javax.swing.JLabel Button6;
    private javax.swing.JLabel Button7;
    private javax.swing.JLabel Button8;
    private javax.swing.JLabel Button9;
    private javax.swing.JLabel Code1;
    private javax.swing.JLabel Code2;
    private javax.swing.JLabel Code3;
    private javax.swing.JLabel Code4;
    private javax.swing.JLabel passcode;
    // End of variables declaration//GEN-END:variables
}
