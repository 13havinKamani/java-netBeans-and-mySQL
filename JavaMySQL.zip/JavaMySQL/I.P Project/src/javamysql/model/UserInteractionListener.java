/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javamysql.model;

/**
 *
 * @author Filippo-TheAppExpert
 */
public interface UserInteractionListener {
    
    boolean signup(User user);
}
